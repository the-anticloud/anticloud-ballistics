# 11 Tutorial Developers

**Project:** BALLISTICS
**Upstream:** https://github.com/ericfischer/ballistics

Content specific to BALLISTICS in category ARTILLERY_MANUFACTURING.
