# 25 Millennium Problem Proposals

**Project:** BALLISTICS
**Upstream:** https://github.com/ericfischer/ballistics

Content specific to BALLISTICS in category ARTILLERY_MANUFACTURING.
