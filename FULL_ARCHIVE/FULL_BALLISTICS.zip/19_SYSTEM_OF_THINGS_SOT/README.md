# 19 System Of Things Sot

**Project:** BALLISTICS
**Upstream:** https://github.com/ericfischer/ballistics

Content specific to BALLISTICS in category ARTILLERY_MANUFACTURING.
